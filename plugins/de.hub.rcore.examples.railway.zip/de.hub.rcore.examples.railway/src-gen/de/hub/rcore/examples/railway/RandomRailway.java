package de.hub.rcore.examples.railway;

import com.google.common.base.Objects;
import de.hub.randomemf.runtime.IGenerator;
import de.hub.randomemf.runtime.Random;
import hu.bme.mit.trainbenchmark.railway.RailwayContainer;
import hu.bme.mit.trainbenchmark.railway.Signal;
import hu.bme.mit.trainbenchmark.railway.Switch;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

@SuppressWarnings("all")
public class RandomRailway implements IGenerator {
  private RailwayContainer model;
  
  private int depth = 0;
  
  private int count = 0;
  
  private int maxCount = -1;
  
  public RandomRailway() {
    
  }
  
  @Override
  public RailwayContainer generate() {
    root();
    de.hub.randomemf.runtime.References.resolveReferences(this, model);
    return model;
  }
  
  @Override
  public RailwayContainer generate(final int maxCount) {
    this.maxCount = maxCount;
    return generate();
  }
  
  public RailwayContainer root() {
    depth += 1;
    hu.bme.mit.trainbenchmark.railway.RailwayContainer result = new Root().generate();
    depth -= 1;
    return result;
  }
  
  private class Root {
    private RailwayContainer self;
    
    public Root() {
      
    }
    
    public hu.bme.mit.trainbenchmark.railway.Semaphore call_0() {
      return callExpr_0();
    }
    
    public hu.bme.mit.trainbenchmark.railway.Semaphore callExpr_0() {
      hu.bme.mit.trainbenchmark.railway.Semaphore _semaphore = RandomRailway.this.semaphore();
      return _semaphore;
    }
    
    public Integer number_0() {
      return Integer.valueOf(23);
    }
    
    public hu.bme.mit.trainbenchmark.railway.Route call_1() {
      return callExpr_1();
    }
    
    public hu.bme.mit.trainbenchmark.railway.Route callExpr_1() {
      hu.bme.mit.trainbenchmark.railway.Route _route = RandomRailway.this.route();
      return _route;
    }
    
    public Integer number_1() {
      return Integer.valueOf(23);
    }
    
    public RailwayContainer generate() {
      if (maxCount >= 0 && count >= maxCount) {
      	return null;
      } else {
      	self = hu.bme.mit.trainbenchmark.railway.RailwayFactory.eINSTANCE.createRailwayContainer();
      	model = self;
      	{
      		org.eclipse.emf.common.util.EList values = (org.eclipse.emf.common.util.EList)self.eGet(self.eClass().getEStructuralFeature("semaphores"));	
      		int iterations = number_0();
      		for (int i = 0; i < iterations; i++) {
      			Object value = call_0();
      			if (value != null) {
      				values.add(value);
      			}
      		}
      	}
      	{
      		org.eclipse.emf.common.util.EList values = (org.eclipse.emf.common.util.EList)self.eGet(self.eClass().getEStructuralFeature("routes"));	
      		int iterations = number_1();
      		for (int i = 0; i < iterations; i++) {
      			Object value = call_1();
      			if (value != null) {
      				values.add(value);
      			}
      		}
      	}
      	count++;
      	return self;
      }
    }
  }
  
  public hu.bme.mit.trainbenchmark.railway.Semaphore semaphore() {
    depth += 1;
    hu.bme.mit.trainbenchmark.railway.Semaphore result = new Semaphore().generate();
    depth -= 1;
    return result;
  }
  
  private class Semaphore {
    private hu.bme.mit.trainbenchmark.railway.Semaphore self;
    
    public Semaphore() {
      
    }
    
    public java.lang.Integer call_0() {
      return callExpr_0();
    }
    
    public java.lang.Integer callExpr_0() {
      int _RandomInt = Random.RandomInt(Integer.MAX_VALUE);
      return Integer.valueOf(_RandomInt);
    }
    
    public Integer number_0() {
      return 1;
    }
    
    public Signal call_1() {
      return callExpr_1();
    }
    
    public Signal callExpr_1() {
      int _RandomInt = Random.RandomInt(3);
      Signal _get = Signal.get(_RandomInt);
      return _get;
    }
    
    public Integer number_1() {
      return 1;
    }
    
    public hu.bme.mit.trainbenchmark.railway.Semaphore generate() {
      if (maxCount >= 0 && count >= maxCount) {
      	return null;
      } else {
      	self = hu.bme.mit.trainbenchmark.railway.RailwayFactory.eINSTANCE.createSemaphore();
      	self.eSet(self.eClass().getEStructuralFeature("id"), call_0());		
      	self.eSet(self.eClass().getEStructuralFeature("signal"), call_1());		
      	count++;
      	return self;
      }
    }
  }
  
  public hu.bme.mit.trainbenchmark.railway.Route route() {
    depth += 1;
    hu.bme.mit.trainbenchmark.railway.Route result = new Route().generate();
    depth -= 1;
    return result;
  }
  
  private class Route {
    private hu.bme.mit.trainbenchmark.railway.Route self;
    
    public Route() {
      
    }
    
    public hu.bme.mit.trainbenchmark.railway.Semaphore call_0() {
      return callExpr_0();
    }
    
    public hu.bme.mit.trainbenchmark.railway.Semaphore callExpr_0() {
      EList<hu.bme.mit.trainbenchmark.railway.Semaphore> _semaphores = RandomRailway.this.model.getSemaphores();
      final Function1<hu.bme.mit.trainbenchmark.railway.Semaphore, Boolean> _function = (hu.bme.mit.trainbenchmark.railway.Semaphore it) -> {
        Signal _signal = it.getSignal();
        return Boolean.valueOf(Objects.equal(_signal, Signal.GO));
      };
      Iterable<hu.bme.mit.trainbenchmark.railway.Semaphore> _filter = IterableExtensions.<hu.bme.mit.trainbenchmark.railway.Semaphore>filter(_semaphores, _function);
      hu.bme.mit.trainbenchmark.railway.Semaphore _Uniform = Random.<hu.bme.mit.trainbenchmark.railway.Semaphore>Uniform(_filter);
      return _Uniform;
    }
    
    public Integer number_0() {
      return 1;
    }
    
    public hu.bme.mit.trainbenchmark.railway.Semaphore call_1() {
      return callExpr_1();
    }
    
    public hu.bme.mit.trainbenchmark.railway.Semaphore callExpr_1() {
      EList<hu.bme.mit.trainbenchmark.railway.Semaphore> _semaphores = RandomRailway.this.model.getSemaphores();
      final Function1<hu.bme.mit.trainbenchmark.railway.Semaphore, Boolean> _function = (hu.bme.mit.trainbenchmark.railway.Semaphore it) -> {
        Signal _signal = it.getSignal();
        return Boolean.valueOf(Objects.equal(_signal, Signal.STOP));
      };
      Iterable<hu.bme.mit.trainbenchmark.railway.Semaphore> _filter = IterableExtensions.<hu.bme.mit.trainbenchmark.railway.Semaphore>filter(_semaphores, _function);
      hu.bme.mit.trainbenchmark.railway.Semaphore _Uniform = Random.<hu.bme.mit.trainbenchmark.railway.Semaphore>Uniform(_filter);
      return _Uniform;
    }
    
    public Integer number_1() {
      return 1;
    }
    
    public hu.bme.mit.trainbenchmark.railway.Sensor call_2() {
      return callExpr_2();
    }
    
    public hu.bme.mit.trainbenchmark.railway.Sensor callExpr_2() {
      hu.bme.mit.trainbenchmark.railway.Sensor _sensor = RandomRailway.this.sensor();
      return _sensor;
    }
    
    public Integer number_2() {
      int _Uniform = Random.Uniform(2, 5);
      return Integer.valueOf(_Uniform);
    }
    
    public hu.bme.mit.trainbenchmark.railway.Route generate() {
      if (maxCount >= 0 && count >= maxCount) {
      	return null;
      } else {
      	self = hu.bme.mit.trainbenchmark.railway.RailwayFactory.eINSTANCE.createRoute();
      	self.eSet(self.eClass().getEStructuralFeature("entry"), call_0());		
      	self.eSet(self.eClass().getEStructuralFeature("exit"), call_1());		
      	{
      		org.eclipse.emf.common.util.EList values = (org.eclipse.emf.common.util.EList)self.eGet(self.eClass().getEStructuralFeature("definedBy"));	
      		int iterations = number_2();
      		for (int i = 0; i < iterations; i++) {
      			Object value = call_2();
      			if (value != null) {
      				values.add(value);
      			}
      		}
      	}
      	count++;
      	return self;
      }
    }
  }
  
  public hu.bme.mit.trainbenchmark.railway.Sensor sensor() {
    depth += 1;
    hu.bme.mit.trainbenchmark.railway.Sensor result = new Sensor().generate();
    depth -= 1;
    return result;
  }
  
  private class Sensor {
    private hu.bme.mit.trainbenchmark.railway.Sensor self;
    
    public Sensor() {
      
    }
    
    public java.lang.Integer call_0() {
      return callExpr_0();
    }
    
    public java.lang.Integer callExpr_0() {
      int _RandomInt = Random.RandomInt(Integer.MAX_VALUE);
      return Integer.valueOf(_RandomInt);
    }
    
    public Integer number_0() {
      return 1;
    }
    
    public hu.bme.mit.trainbenchmark.railway.TrackElement call_1() {
      return callExpr_1();
    }
    
    public hu.bme.mit.trainbenchmark.railway.TrackElement callExpr_1() {
      hu.bme.mit.trainbenchmark.railway.TrackElement _trackElement = RandomRailway.this.trackElement();
      return _trackElement;
    }
    
    public Integer number_1() {
      int _NegBinomial = Random.NegBinomial(2, 0.5);
      return Integer.valueOf(_NegBinomial);
    }
    
    public hu.bme.mit.trainbenchmark.railway.Sensor generate() {
      if (maxCount >= 0 && count >= maxCount) {
      	return null;
      } else {
      	self = hu.bme.mit.trainbenchmark.railway.RailwayFactory.eINSTANCE.createSensor();
      	self.eSet(self.eClass().getEStructuralFeature("id"), call_0());		
      	{
      		org.eclipse.emf.common.util.EList values = (org.eclipse.emf.common.util.EList)self.eGet(self.eClass().getEStructuralFeature("elements"));	
      		int iterations = number_1();
      		for (int i = 0; i < iterations; i++) {
      			Object value = call_1();
      			if (value != null) {
      				values.add(value);
      			}
      		}
      	}
      	count++;
      	return self;
      }
    }
  }
  
  public hu.bme.mit.trainbenchmark.railway.TrackElement trackElement() {
    depth += 1;
    hu.bme.mit.trainbenchmark.railway.TrackElement result = new TrackElement().generate();
    depth -= 1;
    return result;
  }
  
  private class TrackElement {
    private hu.bme.mit.trainbenchmark.railway.TrackElement self;
    
    public TrackElement() {
      
    }
    
    public hu.bme.mit.trainbenchmark.railway.TrackElement call_0() {
      hu.bme.mit.trainbenchmark.railway.Segment _segment = RandomRailway.this.segment();
      return _segment;
    }
    
    public Integer number_0() {
      return 1;
    }
    
    public hu.bme.mit.trainbenchmark.railway.TrackElement call_1() {
      Switch _switchElement = RandomRailway.this.switchElement();
      return _switchElement;
    }
    
    public Integer number_1() {
      return 1;
    }
    
    public hu.bme.mit.trainbenchmark.railway.TrackElement generate() {
      int sum = 0;
      sum += number_0();
      sum += number_1();
      int draw = Random.RandomInt(sum);
      int current = 0;
      current += number_0();
      if (current >= draw) {
      	return call_0();
      }
      current += number_1();
      if (current >= draw) {
      	return call_1();
      }
      throw new IllegalStateException("Unreachable!");
    }
  }
  
  public hu.bme.mit.trainbenchmark.railway.Segment segment() {
    depth += 1;
    hu.bme.mit.trainbenchmark.railway.Segment result = new Segment().generate();
    depth -= 1;
    return result;
  }
  
  private class Segment {
    private hu.bme.mit.trainbenchmark.railway.Segment self;
    
    public Segment() {
      
    }
    
    public java.lang.Integer call_0() {
      return callExpr_0();
    }
    
    public java.lang.Integer callExpr_0() {
      int _Uniform = Random.Uniform(100, 200);
      return Integer.valueOf(_Uniform);
    }
    
    public Integer number_0() {
      return 1;
    }
    
    public hu.bme.mit.trainbenchmark.railway.Segment generate() {
      if (maxCount >= 0 && count >= maxCount) {
      	return null;
      } else {
      	self = hu.bme.mit.trainbenchmark.railway.RailwayFactory.eINSTANCE.createSegment();
      	self.eSet(self.eClass().getEStructuralFeature("length"), call_0());		
      	count++;
      	return self;
      }
    }
  }
  
  public Switch switchElement() {
    depth += 1;
    hu.bme.mit.trainbenchmark.railway.Switch result = new SwitchElement().generate();
    depth -= 1;
    return result;
  }
  
  private class SwitchElement {
    private Switch self;
    
    public SwitchElement() {
      
    }
    
    public Switch generate() {
      if (maxCount >= 0 && count >= maxCount) {
      	return null;
      } else {
      	self = hu.bme.mit.trainbenchmark.railway.RailwayFactory.eINSTANCE.createSwitch();
      	count++;
      	return self;
      }
    }
  }
  
  @Override
  public EObject resolve(final EObject proxy, final EObject source) {
    if (proxy == null) return null;
    String uri = ((org.eclipse.emf.ecore.InternalEObject)proxy).eProxyURI().toString();
    if (uri.equals("route_0")) {
    	Route rule = new Route();
    	rule.self = (hu.bme.mit.trainbenchmark.railway.Route)source;
    	return rule.callExpr_0();
    }
    if (uri.equals("route_1")) {
    	Route rule = new Route();
    	rule.self = (hu.bme.mit.trainbenchmark.railway.Route)source;
    	return rule.callExpr_1();
    }
    return null;
  }
}
