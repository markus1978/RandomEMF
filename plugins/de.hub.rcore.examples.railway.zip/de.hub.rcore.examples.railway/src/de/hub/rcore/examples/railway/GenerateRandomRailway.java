package de.hub.rcore.examples.railway;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

import hu.bme.mit.trainbenchmark.railway.RailwayContainer;

public class GenerateRandomRailway {
	public static void main(String[] args) throws Exception {
		RandomRailway randomRailway = new RandomRailway();
		RailwayContainer railway = randomRailway.generate();
		
		Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("xmi", new XMIResourceFactoryImpl());
		
		ResourceSet rs = new ResourceSetImpl();
		Resource output = rs.createResource(URI.createURI("output.xmi"));
		output.getContents().add(railway);
		output.save(null);
	}
}
